# 知序独立后端：FastAPI + SQLAlchemy + MySQL 8.0

这份目录独立于 Vue 前端，提供当前页面需要的 **42 个 API 操作、14 张关系表、Alembic 迁移**。业务字段沿用前端 camelCase。正式注册默认空数据；只有显式体验入口才创建样例。

先阅读以下独立文档：

- [QQ 邮箱验证码注册与授权码配置](docs/EMAIL_REGISTRATION.md)

- [MySQL 8.0 配置与启动步骤](docs/MYSQL8_SETUP.md)
- [从登录到知识星图的接口调用教程](docs/USAGE_GUIDE.md)
- [完整接口与参数 description](docs/API_REFERENCE.md)
- [每个函数的作用与源码位置](docs/FUNCTION_REFERENCE.md)
- [数据库表结构](docs/DATABASE_SCHEMA.md)
- [前端每个页面如何联调](docs/FRONTEND_INTEGRATION.md)
- [本轮验证结果与限制](docs/VERIFICATION.md)

## 快速启动

在本目录打开 PowerShell（交付后为 `D:/zhiqu-backend/backend`）：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.lock.txt
if (-not (Test-Path .env)) { Copy-Item .env.example .env }
```

按数据库配置文档创建专用库、账号并填写 `.env`。然后：

```powershell
.\.venv\Scripts\python.exe scripts\check_database.py
.\.venv\Scripts\python.exe -m alembic upgrade head
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

打开 http://127.0.0.1:8000/docs，按邮箱注册文档配置 SMTP 后先发送验证码，再注册账号，最后点 Authorize 输入注册/登录返回的 accessToken。
API 前缀地址 http://127.0.0.1:8000/api/v1 会显示文档与健康检查入口。服务启动要求真实 MySQL 连接和迁移正确；不会静默改用 SQLite。

## 文件职责

```text
app/main.py          应用入口、CORS、错误处理、启动检查
app/config.py        .env 配置和安全构造 MySQL URL
app/database.py      SQLAlchemy 引擎、连接池和 Session 工厂
app/models.py        用户、会话、课程、资料等 14 张 ORM 表
app/dependencies.py  每请求事务、鉴权、所有权、分页和限流依赖
app/parameters.py    Path/Query 参数类型和 description
app/schemas.py       请求模型、校验和认证响应模型
app/responses.py     有字段说明的响应模型和错误结构
app/auth.py          注册、登录、退出和个人资料接口
app/resources.py     课程、文件资料、复习任务接口
app/study.py         题库、作答、错题、报告和星图接口
app/assistant.py     课程资料问答和问答历史接口
app/services.py      文本/PDF 解析、引用检索和可选外部模型
app/data_api.py      本人学习记录导出与重置
app/serializers.py   ORM 记录转换为前端字段
migrations/          Alembic 表结构版本
sql/                 手工建库与账号权限脚本
scripts/             连接诊断、自动导出接口文档
docs/                独立接口、函数、数据库及联调文档
examples/            Vue 2 请求封装和完整调用脚本
tests/               鉴权、隔离、持久化、迁移和文档契约检查
```

## 测试与文档更新

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe scripts\export_docs.py
```

默认回归测试显式注入独立测试引擎，并不等于真实 MySQL 联测；生产路径只使用 MySQL。数据库真实联测的设置和结果见验证文档。

此服务提供个人学习数据功能，尚不包含教师/学生考试权限、找回密码、OCR、自动知识抽取或自动出题。问答默认资料检索，配置模型后才请求外部服务。JSON 导出不是完整数据库备份。

## 个人星图配置（2.3.0，历史）
此版本的账号级模板流程已停用，由下述 2.4.0 课程级手动配置替代；历史课程与资料保留。


## 课程知识星图（2.4.0）
流程调整为先创建课程、再手动配置该课程的知识点和关系，可选关联复习任务；不再要求登录时配置账号星图。0004 仅新增两张表，旧课程与资料保留。详见 [课程星图使用说明](docs/KNOWLEDGE_SETUP.md)。


## JSON 题库导入（2.5.0）
按已有课程批量追加 JSON 单选题，完整重复跳过；真实账号练习、判分、错题、报告和总览已接后端。复用现有表，迁移仍为 0004，无需改 MySQL 配置。详见 [题库使用说明](docs/QUESTION_BANK.md) 与 [接口接入核查](docs/API_INTEGRATION_AUDIT.md)。


## 本轮接口接入（2.6.0）

题库选项展示、课程分类、前端示例预览、PDF 跨会话读取、问答/历史、作答历史及其余接口入口均已接通。无新迁移。见 [使用说明](docs/COURSE_DATA_GUIDE.md) 和 [42 项接口清单](docs/API_INTEGRATION_AUDIT.md)。
